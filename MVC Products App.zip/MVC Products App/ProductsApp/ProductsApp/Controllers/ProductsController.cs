﻿using System.Linq;
using System.Web.Mvc;

namespace ProductsApp.Controllers
{
    public class ProductsController : Controller
    {
        ProductAppDBContext dbContext = new ProductAppDBContext();
        // GET: Products
        public ActionResult Index()
        {
            var productsList = dbContext.Products.ToList();
            return View(productsList);
        }

        public ActionResult Details(int id)
        {
            var productDetails = dbContext.Products.Where(p => p.ID == id).FirstOrDefault();
            return View(productDetails);
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                var entry = dbContext.Entry(product);
                entry.State = System.Data.Entity.EntityState.Modified;
                dbContext.SaveChanges();

                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Create(int id)
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                dbContext.Products.Add(product);
                dbContext.SaveChanges();
                return RedirectToAction("Details", new { id = product.ID });
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        [HttpGet]
        public ActionResult Delete(int id)
        {
            return View();
        }
        public ActionResult Delete(Product product)
        {
            var deleteItem = dbContext.Products.Where(p => p.ID == product.ID).FirstOrDefault();
            dbContext.Products.Remove(deleteItem);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}